import React from "react";
import { Grid, Typography, AppBar, Toolbar, Button } from "@material-ui/core";
import { button } from "../../StyledComponents";
import { typography } from "../../StyledComponents";

export default function Footer(props) {
  return (
    <AppBar
      position={props.position}
      color="white"
      style={{ 
               top: "auto", 
               background: '#00578E',
               bottom:"auto",
               
               }}
    >
      <Toolbar>
        <Grid 
          container
          direction="row"
          alignItems="flex-end"
          spacing={1}
      
        >
          <Grid item style={{ marginRight: "auto" }}>
          
            <Typography style={typography} variant="body2" >
              © 2020 Broadridge Financial Solutions, Inc.
            </Typography>
          </Grid>
          <Grid item>
            <Button style={button}>
              <Typography style={typography} variant="body2" color="primary">
                Accessibility Statement
              </Typography>
            </Button>
          </Grid>
          <Grid item>
            <Button style={button}>
              <Typography style={typography} variant="body2" color="primary">
                Privacy Statement 
              </Typography>
            </Button>
          </Grid>
          <Grid item>
            <Button style={button}>
              <Typography style={typography} variant="body2" color="primary" >
                Terms and Conditions 
              </Typography>
            </Button>
          </Grid>
        </Grid>
      </Toolbar>
    </AppBar>
  );
}

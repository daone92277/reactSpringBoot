import React from "react";
import { Typography, AppBar, Toolbar, Divider, MenuItem, Menu } from "@material-ui/core";
import logo from "../../images/br-logo-white.svg"; 
import {  Link } from "react-router-dom";
import Footer from "../Footer/Footer";
import { link } from "../../StyledComponents";



export default function Header(props) {
    return (

        <div className="container">
            <AppBar style={{ background: '#00578E' }} >
                <Toolbar variant="dense">
                    <img
                        src={logo}
                        alt="Broadridge Company"
                        style={{ width: "140px", marginLeft: "-10px" }}
                    />
                    <Divider
                        orientation="vertical"
                        flexItem
                        style={{ marginLeft: "15px", marginRight: "15px"  }}
                    />
                    <Link to="/" style={link} >
                        <Typography style={{fontFamily: "sans-serif"}} variant="h6">SRD Integration</Typography>
                    </Link>
                </Toolbar>
            </AppBar>
                

            {/* <Footer /> */}
        </div>
    )
}
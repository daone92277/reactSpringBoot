import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import '../../styles/card.css'
import { HashRouter, Link, Switch, Route } from "react-router-dom";


export default function MediaCard() {
 

  return (
    <div className="sri_section">
   <div className ="title">
      <h2>Systems Requirement Inventory</h2>
   </div>
   <div className ="body">
      <p>
         The systems requirement document is a tool to capture print and digital requirements.
         This application aims to document the requirements necessary to process and print the
         related Control Reports between Broadridge Customer Communications and the client. 
      </p>
   </div>
   <div className="bottom_section">
      <div className = "clientNameTitle">
         <h4>Client Name</h4>
      </div>
      <div className = "clientSelectBox">
         <select name="clientSelect" id="clients">
            <option value="default">Select One</option>
            <option value="jpmr">Jp Morgan</option>
            <option value="dad">Da Davidson</option>
            <option value="mercedes">Mercedes</option>
            <option value="apex">Apex Systems</option>
         </select>
      </div>
      <div className = "systemNameTitle">
         <h4>System Name</h4>
      </div>
      <div className = "systemSelectBox">
         <select className="systemSelect" id="Systems">
            <option value="default">Select One</option>
            <option value="dm">Delivery Manager</option>
            <option value="dis">DIS</option>
            <option value="cm">Control Manager</option>
            <option value="presentment">Presentment</option>
         </select>
         <div className="newButton">
            <Link to ="/Summary">
            <button className="newButton" type="submit">New</button>
            </Link>
         </div>
      </div>
      <div className="submitButton">
         <button type="submit">Submit</button>
      </div>
      <br></br>
   </div>
</div>
    
    
    
  );
}

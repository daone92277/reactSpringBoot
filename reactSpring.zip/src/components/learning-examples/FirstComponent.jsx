import React, { Component } from 'react';



class FirstComponent extends Component {
    
        render() {
          return (
            <div className = "firstComponent">
              <h1>First Component1</h1>
              
            </div>
          );
        }
      
}

export default FirstComponent;
import React, { Component } from 'react';


class SecondComponent extends Component {
    render() {
              return (
                <div className = "secondComponent">
                  <h1>Second Component</h1>
                </div>
              );
            }
          }


export default SecondComponent;
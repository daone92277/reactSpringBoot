import React, { Component } from 'react';

class ThirdComponent extends Component {
    render() {
        return (
            <div className = "ThirdComponent">
              <h1>Third Component</h1>
            </div>
          );
    }
}

export default ThirdComponent;
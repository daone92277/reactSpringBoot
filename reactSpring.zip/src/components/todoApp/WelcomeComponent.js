import React, { Component } from 'react';
import { BrowserRouter as Link } from 'react-router-dom'


class WelcomeComponent extends Component {
    render() {
        return (


            <div className="container">
                <h1>Welcome!</h1>
                <h4>You can manage your Todos <Link to="/todos">Here</Link>
                </h4>
            </div >
        );
    }
}

export default WelcomeComponent;
import React, { Component, props } from 'react';
import AuthenticationService from './AuthenticationService'

class LoginComponent extends Component {
    constructor() {
        super(props)
        this.state = {
            username: '',

        }

        this.state = {
            hIDden: true,
            password: ''
        }

        this.state = {
            hasLoginFailed: false,
            showSuccessMessage: false
        }
        this.handleChange = this.handleChange.bind(this)
        this.toggleShow = this.toggleShow.bind(this);
        //this.loginClicked = this.loginClicked.bind(this)
    }

    handleChange(event) {
        console.log(this.state);
        this.setState({ [event.target.name]: event.target.value })
    }

    toggleShow() {
        this.setState({ hIDden: !this.state.hIDden });
    }

    loginClicked() {

        if (this.state.username === 'greened' && this.state.password === 'Develop10!') {
            AuthenticationService.registerSuccessfulLogin(this.state.username, this.state.password)
            this.props.history.push(`/welcome/${this.state.username}`)
            this.setState({ showSuccessMessage: true })
            this.setState({ hasLoginFailed: false })
        }

        else {
            this.setState({ showSuccessMessage: false })
            this.setState({ hasLoginFailed: true })
        }
    }

    render() {
        return (
            <div>
                <h3>Login Page</h3>
                <br></br>
                <div className="container">
                    {this.state.hasLoginFailed && <div className="alert alert-warning">Invalid Credentials</div>}
                    {this.state.showSuccessMessage && <div>Login Successful</div>}


                User Name: <input type="text" name="username" value={this.state.username} onChange={this.handleChange} />
                    {'\u00A0'}Password: <input type={this.state.hIDden ? 'password' : 'text'} name="password" value={this.state.password} onChange={this.handleChange}></input>
                    {'\u00A0'}
                    <button onEvent={this.handleKeyPress} onClick={this.toggleShow.bind(this)}>Show/Hide</button>
                    {'\u00A0'}
                    <button className="btn btn-success" onClick={this.loginClicked.bind(this)}>Submit</button>
                </div>
            </div>

        );
    }
}

export default LoginComponent;
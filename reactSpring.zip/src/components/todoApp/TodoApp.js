import React, { Component } from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom'


import LoginComponent from './LoginComponent.js'
import ListTodoComponent from './TodoList.js'
import HeaderComponent from './HeaderComponent.js'
import FooterComponent from './FooterComponent.js'
import LogoutComponent from './LogoutComponent.js'
import WelcomeComponent from './WelcomeComponent.js'
import ErrorComponent from './ErrorComponent.js'



const Todo = {
    margin: "20px",
}

class TodoApp extends Component {
    render() {
        return (
            <div style={Todo} className="Todo"  >
                <Router>
                    <>
                        <HeaderComponent />
                        <Switch>
                            <Route path="/" exact component={LoginComponent} />
                            <Route path="/login" component={LoginComponent} />
                            <Route path="/welcome" component={WelcomeComponent} />
                            <Route path="/todos" component={ListTodoComponent} />
                            <Route path="/logout" component={LogoutComponent} />
                            <Route component={ErrorComponent} />

                        </Switch>
                        <FooterComponent />
                    </>
                </Router>
            </div>
        );
    }
}







function ShowInvalIDCredentials(props) {
    if (props.hasLoginFailed) {
        return <div>InvalID username or password, please try again!"</div>
    } else
        return null
}

function ShowLoginSuccessMessage(props) {
    if (props.showSuccessMessage) {
        return <div>You are logged in !</div>
    }
    else {
        return null
    }
}

export default TodoApp;

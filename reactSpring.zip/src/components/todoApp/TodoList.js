
import React, { Component } from 'react';
import { format } from 'date-fns';





class ListTodoComponent extends Component {
    constructor(props) {
        super(props)
        this.state = {
            todos:
                [
                    { ID: 1, Description: 'Learn To Dance', Done: false, TargetDate: format(new Date(), 'MM/dd/yyyy kk:mm:ss') },
                    { ID: 2, Description: 'Learn to Code', Done: false, TargetDate: format(new Date(), 'MM/dd/yyyy kk:mm:ss') },
                    { ID: 3, Description: 'Visit California', Done: false, TargetDate: format(new Date(), 'MM/dd/yyyy kk:mm:ss') },
                    { ID: 4, Description: 'Get a Promotion', Done: false, TargetDate: format(new Date(), 'MM/dd/yyyy kk:mm:ss') },
                ]

        }
    }


    render() {
        return (
            <div>
                <h2>My Todo List</h2>
                <div className="container">
                    <table className="table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Description</th>
                                <th>Target Date</th>
                                <th>Is Completed</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                this.state.todos.map(
                                    todo =>
                                        < tr >
                                            <td>{todo.ID}</td>
                                            <td>{todo.Description}</td>
                                            <td>{todo.Done.toString()}</td>
                                            <td>{todo.TargetDate.toString()}</td>
                                        </tr>
                                )
                            }
                        </tbody>
                    </table>
                </div>
            </div >
        );
    }
}

export default ListTodoComponent; 
import React from 'react';





function ErrorComponent() {
    return <div>
        <h2>An error occurred please check your page address or contact support for more help</h2>
    </div>
}

export default ErrorComponent;

import React, { Component } from 'react';
import { BrowserRouter as Link } from 'react-router-dom'

import AuthenticationService from './AuthenticationService'


class HeaderComponent extends Component {
    render() {
        return (
            <header>
                <nav class="navbar navbar-expand-md navbar-dark bg-dark">
                    <a class="navbar-brand" href="https://www.linkedin.com/in/david-greene-76186813b/">ToDo Application</a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNav">
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <a class="nav-link" href="/welcome">Home <span class="sr-only">(current)</span></a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="/todos">To do List</a>
                            </li>
                            <ul class="navbar-nav navbar-collapse justify-content-end" >
                                <li class="nav-item ml-auto">
                                    <a class="nav-link" href="/login">Login</a>
                                </li>
                                <li class="nav-item" >
                                    <Link class="nav-link" to="/logout" onClick={AuthenticationService.logout}>Logout</Link>
                                </li>
                            </ul>
                        </ul>
                    </div>
                </nav>
            </header>

        );
    }
}

export default HeaderComponent;